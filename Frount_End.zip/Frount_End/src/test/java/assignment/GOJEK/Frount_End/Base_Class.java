package assignment.GOJEK.Frount_End;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Base_Class {
	static WebDriver driver;
	static WebDriverWait wait;
	By buy_Button = By.xpath("//a[@class='btn buy']");
	By checkout = By.xpath("//div[@class='cart-checkout']");
	By conti = By.xpath("//a[@href='#/select-payment']");
	By card = By.xpath("//a[@class='list with-promo']");
	By card_n = By.xpath("//input[@name='cardnumber']");
	By exday = By.xpath("//input[@placeholder='MM / YY']");
	By cvv = By.xpath("//input[@placeholder='123']");
	By paynow = By.xpath("//a[@class='button-main-content']");
	By otp = By.xpath("//input[@name='PaRes']");
	By s_otp = By.xpath("//button[@type='submit']");

	public void setUp(String browser) {
		if (browser.equalsIgnoreCase("Chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		} else if (browser.equalsIgnoreCase("Firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		} else {
			System.out.println("Invalid Value Entered");
		}
	}
	
	public void waitAndClick(By locator) {
		wait = new WebDriverWait(driver, 2000);
		wait.until(ExpectedConditions.visibilityOf(getelement(locator)));
		doclick(locator);
	}
	public void doclick(By locator) {
		driver.findElement(locator).click();
	}

	public void launchurl(String url) {
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get(url);
	}

	public WebElement getelement(By locator) {
		WebElement element = driver.findElement(locator);
		return element;
	}

	public void doSendkeys(By locator, String value) {
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(locator).clear();
		driver.findElement(locator).sendKeys(value);

	}

	public void movetoelement(By locator) {
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(locator)).build().perform();
	}
}
