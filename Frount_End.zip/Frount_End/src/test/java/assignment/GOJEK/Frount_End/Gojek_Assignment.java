package assignment.GOJEK.Frount_End;

import java.awt.Frame;

import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

/**
 * @author Yashkarn
 *
 */
public class Gojek_Assignment extends Base_Class {
	
	@BeforeTest
	public void setupbrowser() {
		setUp("chrome");
	}

	@Test(testName = "Positive Test Case" )
	public void gojek_Positive_Demo() throws InterruptedException {
		// Open Url
		launchurl("https://demo.midtrans.com/");
		String buybuttontext = getelement(buy_Button).getText();
		Assert.assertEquals(buybuttontext, "BUY NOW");
		// click on the buy button
		doclick(buy_Button);
		waitAndClick(checkout); // click on checkout Button 
		Thread.sleep(2000);
		driver.switchTo().frame("snap-midtrans");  // Switch the Frame 
		waitAndClick(conti);					   // wait for Continue Button to display before click on it 
		waitAndClick(card);					       // wait for Card Button to display before click on it 
		doSendkeys(card_n, "4811 1111 1111 1114"); // Enter the Card Number 
		doSendkeys(exday, "0420");					// Enter the Expire date 
		doSendkeys(cvv, "123");						// Enter the CVV 
		waitAndClick(paynow); 						// Click on Pay Now to make the payment 
		// waitAndClick(conti_to_Payment);
		Thread.sleep(9000);
		driver.switchTo().frame(0);
		doSendkeys(otp, "112233");
		doclick(s_otp);
		Thread.sleep(2000);
		driver.switchTo().frame("snap-midtrans");
		Assert.assertTrue(driver.getPageSource().contains("Transaction successful"), "Test Case Passed"); // Check if the Transaction is happened or not 
	}

	@Test(testName = "Negitive Test Case" ,dependsOnMethods = "gojek_Positive_Demo")
	public void gojek_Negitive_Demo() throws InterruptedException {
		// Open Url
		launchurl("https://demo.midtrans.com/");
		// click on the buy button
		doclick(buy_Button);
		waitAndClick(checkout);
		Thread.sleep(2000);
		driver.switchTo().frame("snap-midtrans");
		waitAndClick(conti);
		waitAndClick(card);
		doSendkeys(card_n, "4911 1111 1111 1113");
		doSendkeys(exday, "0420");
		doSendkeys(cvv, "123");
		waitAndClick(paynow);
		// waitAndClick(conti_to_Payment);
		Thread.sleep(9000);
		driver.switchTo().frame(0);
		doSendkeys(otp, "112233");
		doclick(s_otp);
		Thread.sleep(2000);
		driver.switchTo().frame("snap-midtrans");
		Assert.assertTrue(driver.getPageSource().contains("Transaction successful"), "Test Case Failed ");
	}

	@AfterTest
	public void tearDown() {
		driver.quit();
	}

}
